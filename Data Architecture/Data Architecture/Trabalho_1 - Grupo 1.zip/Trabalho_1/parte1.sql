CREATE TABLE `Investimentos`(
    `id_investimento` BIGINT NOT NULL,
    `id_conta` BIGINT NOT NULL,
    `nome_investimento` VARCHAR NOT NULL,
    `valor` DECIMAL NOT NULL,
    PRIMARY KEY(`id_investimento`)
);
ALTER TABLE
    `Investimentos` ADD INDEX `investimentos_id_conta_index`(`id_conta`);
ALTER TABLE
    `Investimentos` ADD INDEX `investimentos_nome_investimento_index`(`nome_investimento`);
ALTER TABLE 
    `Investimentos` ADD INDEX `investimentos_valor_index`(`valor`);
CREATE TABLE `Linha de Crédito`(
    `perfil_credito` BIGINT NOT NULL,
    `id_conta` BIGINT NOT NULL,
    PRIMARY KEY(`perfil_credito`)
);
ALTER TABLE
    `Linha de Crédito` ADD INDEX `linha de crédito_id_conta_index`(`id_conta`);
CREATE TABLE `Cadastro`(
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `n_documento` VARCHAR NOT NULL,
    `nome` VARCHAR NOT NULL,
    `idade` TINYINT NOT NULL
);
ALTER TABLE
    `Cadastro` ADD INDEX `cadastro_n_documento_index`(`n_documento`);
ALTER TABLE
    `Cadastro` ADD INDEX `cadastro_nome_index`(`nome`);
ALTER TABLE
    `Cadastro` ADD INDEX `cadastro_idade_index`(`idade`);
CREATE TABLE `Transação`(
    `id_transacao` BIGINT NOT NULL,
    `id_conta` BIGINT NOT NULL,
    `saldo_transacao` DECIMAL NOT NULL,
    `tipo` VARCHAR NOT NULL,
    PRIMARY KEY(`id_transacao`)
);
ALTER TABLE
    `Transação` ADD INDEX `transação_id_conta_index`(`id_conta`);
ALTER TABLE
    `Transação` ADD INDEX `transação_saldo_transacao_index`(`saldo_transacao`);
ALTER TABLE
    `Transação` ADD INDEX `transação_tipo_index`(`tipo`);
CREATE TABLE `Conta`(
    `id_conta` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `id` BIGINT NOT NULL,
    `saldo` DECIMAL NOT NULL,
    `perfil_credito` BIGINT NOT NULL
);
ALTER TABLE
    `Conta` ADD INDEX `conta_id_index`(`id`);
ALTER TABLE
    `Conta` ADD INDEX `conta_saldo_index`(`saldo`);
ALTER TABLE
    `Conta` ADD INDEX `conta_perfil_credito_index`(`perfil_credito`);
ALTER TABLE
    `Investimentos` ADD CONSTRAINT `investimentos_valor_foreign` FOREIGN KEY(`valor`) REFERENCES `Conta`(`saldo`);
ALTER TABLE
    `Transação` ADD CONSTRAINT `transação_saldo_transacao_foreign` FOREIGN KEY(`saldo_transacao`) REFERENCES `Conta`(`saldo`);
ALTER TABLE
    `Transação` ADD CONSTRAINT `transação_id_conta_foreign` FOREIGN KEY(`id_conta`) REFERENCES `Conta`(`id_conta`);
ALTER TABLE
    `Conta` ADD CONSTRAINT `conta_id_conta_foreign` FOREIGN KEY(`id_conta`) REFERENCES `Investimentos`(`id_conta`);
ALTER TABLE
    `Conta` ADD CONSTRAINT `conta_id_conta_foreign` FOREIGN KEY(`id_conta`) REFERENCES `Linha de Crédito`(`id_conta`);
ALTER TABLE
    `Conta` ADD CONSTRAINT `conta_id_foreign` FOREIGN KEY(`id`) REFERENCES `Cadastro`(`id`);
ALTER TABLE
    `Conta` ADD CONSTRAINT `conta_perfil_credito_foreign` FOREIGN KEY(`perfil_credito`) REFERENCES `Linha de Crédito`(`perfil_credito`);